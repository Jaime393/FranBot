#!/data/data/com.termux/files/usr/bin/bash
echo "🧠 Instalando SuperLocalMemory integrado..."

# Verificar raíz
if [ ! -f "js/franbot-core.js" ]; then
    echo "❌ No estás en la raíz de FranBot."
    exit 1
fi

# Backup
cp js/franbot-core.js js/franbot-core.js.backup.$(date +%s)
cp js/super-local-memory.js js/super-local-memory.js.backup.$(date +%s)

# Reemplazar super-local-memory.js
cp super-local-memory.js js/super-local-memory.js
echo "✅ super-local-memory.js actualizado."

# Aplicar parche manual (diff) a franbot-core.js
# Insertamos las llamadas en los lugares exactos con sed
# 1. Inicialización en constructor
sed -i '/^class FranBotCore {/,/^  constructor() {/ {
  /constructor() {/a\
    if (typeof SuperLocalMemory !== '\''undefined'\'') {\
      this.estado.campo_conceptual = SuperLocalMemory.inicializar(this.estado.campo_conceptual);\
    }
}' js/franbot-core.js

# 2. Refuerzo en método responder (tras obtener respuesta)
sed -i '/^  responder(/,/^  }/ {
  /return respuesta;/i\
    const palabras = mensaje.toLowerCase().split(/\\s+/);\
    palabras.forEach(p => {\
      if (this.estado.campo_conceptual.nodos[p]) {\
        this.estado.campo_conceptual = SuperLocalMemory.reforzar(this.estado.campo_conceptual, p);\
      }\
    });
}' js/franbot-core.js

# 3. Consolidación en método soñar
sed -i '/^  soñar() {/,/^  }/ {
  /this._guardarEstado();/i\
    if (typeof SuperLocalMemory !== '\''undefined'\'') {\
      this.estado.campo_conceptual = SuperLocalMemory.consolidar(this.estado.campo_conceptual);\
    }
}' js/franbot-core.js

echo "✅ Parches aplicados a franbot-core.js."
echo "🎉 Instalación completada. El olvido biológico está activo."
