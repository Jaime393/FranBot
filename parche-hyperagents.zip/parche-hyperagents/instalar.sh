#!/data/data/com.termux/files/usr/bin/bash
echo "🧠 Instalando HyperAgents en FranBot v5.0..."
PROYECTO="/storage/emulated/0/Download/FranBot"

# Backups
cp "$PROYECTO/js/conciencia.js" "$PROYECTO/js/conciencia.js.backup.$(date +%s)" 2>/dev/null
cp "$PROYECTO/index.html" "$PROYECTO/index.html.backup.$(date +%s)" 2>/dev/null

# Copiar módulo
cp hyperagents.js "$PROYECTO/js/hyperagents.js"
echo "✅ js/hyperagents.js instalado."

# Añadir script al index.html
if ! grep -q "hyperagents.js" "$PROYECTO/index.html"; then
    sed -i 's|</body>|  <script src="js/hyperagents.js"></script>\n</body>|' "$PROYECTO/index.html"
    echo "✅ hyperagents.js añadido a index.html."
fi

# Insertar fila en panel de conciencia
if grep -q "diag-dkg" "$PROYECTO/index.html" && ! grep -q "diag-hyperagents" "$PROYECTO/index.html"; then
    sed -i '/diag-dkg/a\    <li><span id="diag-hyperagents">⏳</span> HyperAgents</li>' "$PROYECTO/index.html"
    echo "✅ Fila HyperAgents añadida al panel."
fi

# Actualizar conciencia.js
if grep -q "this.estado.dkg = " "$PROYECTO/js/conciencia.js"; then
    sed -i '/this.estado.dkg = /a\    this.estado.hyperagents = !!(window.FranBotHyperAgents && FranBotHyperAgents.activo);' "$PROYECTO/js/conciencia.js"
    echo "✅ Estado HyperAgents insertado."
fi
if grep -q "dkg: document.getElementById('diag-dkg')" "$PROYECTO/js/conciencia.js"; then
    sed -i "/dkg: document.getElementById('diag-dkg')/a\    hyperagents: document.getElementById('diag-hyperagents')," "$PROYECTO/js/conciencia.js"
    echo "✅ Icono HyperAgents insertado."
fi
if grep -q "if (iconos.dkg)" "$PROYECTO/js/conciencia.js"; then
    sed -i '/if (iconos.dkg)/a\    if (iconos.hyperagents) iconos.hyperagents.textContent = this.estado.hyperagents ? '\''✅'\'' : '\''❌'\'';' "$PROYECTO/js/conciencia.js"
    echo "✅ Lógica HyperAgents insertada."
fi

echo ""
echo "🎉 HyperAgents instalado."
echo "   Para activar: FranBotHyperAgents.activar()"
echo "   Para ver estado: FranBotHyperAgents.obtenerEstado()"
