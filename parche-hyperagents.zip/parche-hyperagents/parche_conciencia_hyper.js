// Añadir al final de diagnosticar()
this.estado.hyperagents = !!(window.FranBotHyperAgents && FranBotHyperAgents.activo);
// Añadir al objeto iconos
hyperagents: document.getElementById('diag-hyperagents'),
// Añadir en actualizarPanel()
if (iconos.hyperagents) iconos.hyperagents.textContent = this.estado.hyperagents ? '✅' : '❌';
