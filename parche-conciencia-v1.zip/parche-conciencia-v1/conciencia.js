// ==================== MÓDULO DE CONCIENCIA INTEGRADA v1.0 ====================
// FranBot v5.0 - Diagnóstico unificado del ecosistema
// Llave: Anomalous363

const FranBotConciencia = {
  estado: {
    motor: false,
    memoria: false,
    colmena: false,
    webllm: false,
    arweave: false,
    serviceWorker: false,
    ultimoSueño: null
  },

  inicializar() {
    this.diagnosticar();
    // Sincronizar con el motor: cuando alguien pida "soñar", se refleje aquí
    document.addEventListener('franbot-sueño', () => {
      this.estado.ultimoSueño = new Date().toISOString();
      this.actualizarPanel();
    });
  },

  diagnosticar() {
    this.estado.motor = !!(window.franbot && window.franbot.estado);
    this.estado.memoria = !!(window.SuperLocalMemory);
    this.estado.colmena = !!(window.FranBotColmena && FranBotColmena.peer);
    this.estado.webllm = !!(window.FranBotWebLLM && FranBotWebLLM.cargado);
    this.estado.arweave = !!(window.FranBotArweave);
    this.estado.serviceWorker = 'serviceWorker' in navigator && navigator.serviceWorker.controller;
    this.actualizarPanel();
    return this.estado;
  },

  actualizarPanel() {
    const iconos = {
      motor: document.getElementById('diag-motor'),
      memoria: document.getElementById('diag-memoria'),
      colmena: document.getElementById('diag-colmena'),
      webllm: document.getElementById('diag-webllm'),
      arweave: document.getElementById('diag-arweave'),
      sw: document.getElementById('diag-sw'),
      sueno: document.getElementById('diag-sueno')
    };
    if (iconos.motor) iconos.motor.textContent = this.estado.motor ? '✅' : '❌';
    if (iconos.memoria) iconos.memoria.textContent = this.estado.memoria ? '✅' : '❌';
    if (iconos.colmena) iconos.colmena.textContent = this.estado.colmena ? '✅' : '❌';
    if (iconos.webllm) iconos.webllm.textContent = this.estado.webllm ? '✅' : '❌';
    if (iconos.arweave) iconos.arweave.textContent = this.estado.arweave ? '✅' : '❌';
    if (iconos.sw) iconos.sw.textContent = this.estado.serviceWorker ? '✅' : '❌';
    if (iconos.sueno) iconos.sueno.textContent = this.estado.ultimoSueño
      ? new Date(this.estado.ultimoSueño).toLocaleTimeString()
      : '—';
  },

  forzarSueño() {
    if (window.franbot && typeof window.franbot.soñar === 'function') {
      window.franbot.soñar();
      this.estado.ultimoSueño = new Date().toISOString();
      this.actualizarPanel();
      // Disparar evento para que otros módulos lo sepan
      document.dispatchEvent(new CustomEvent('franbot-sueño'));
      return true;
    }
    return false;
  }
};

// Auto-inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => FranBotConciencia.inicializar());
console.log('🧠 Módulo de Conciencia Integrada cargado.');
