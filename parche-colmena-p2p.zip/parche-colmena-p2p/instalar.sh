#!/data/data/com.termux/files/usr/bin/bash
echo "🐝 Instalando Colmena P2P en FranBot v5.0..."

# Verificar raíz
if [ ! -f "index.html" ]; then
    echo "❌ No estás en la raíz de FranBot."
    exit 1
fi

# Backups
cp js/app.js js/app.js.backup.$(date +%s) 2>/dev/null
cp index.html index.html.backup.$(date +%s) 2>/dev/null

# Copiar nuevo módulo
cp colmena-p2p.js js/colmena-p2p.js
echo "✅ js/colmena-p2p.js instalado."

# Añadir scripts al index.html (si no existen)
if ! grep -q "peerjs" index.html; then
    sed -i 's|</body>|  <script src="https://unpkg.com/peerjs@1.5.1/dist/peerjs.min.js"></script>\n</body>|' index.html
    echo "✅ PeerJS CDN añadido."
fi
if ! grep -q "colmena-p2p.js" index.html; then
    sed -i 's|</body>|  <script src="js/colmena-p2p.js"></script>\n</body>|' index.html
    echo "✅ colmena-p2p.js añadido."
fi

# Insertar panel de colmena después del tools-menu
if ! grep -q "colmena-panel" index.html; then
    sed -i '/id="tools-menu"/{
        /<\/div>/a\
        '"$(sed 's/"/\\"/g' panel_colmena.html)"'
    }' index.html
    echo "✅ Panel de colmena insertado."
fi

# Parchear app.js: reemplazar el manejador de btn-colmena
if grep -q "btn-colmena" js/app.js; then
    # Eliminar bloque antiguo (desde 'btn-colmena' hasta el cierre del listener)
    # Método simple: borrar línea que contiene 'btn-colmena' y reemplazarla con el nuevo código
    sed -i "/btn-colmena/,/^$/{
        /btn-colmena/{
            r parche_app_colmena.js
            d
        }
        /^$/d
    }" js/app.js
    echo "✅ app.js parcheado (btn-colmena)."
else
    echo "⚠️ No se encontró btn-colmena en app.js. Añade manualmente el código de parche_app_colmena.js."
fi

echo "🎉 Colmena P2P instalada. Abre FranBot, pulsa 'Colmena' y comparte tu ID."
