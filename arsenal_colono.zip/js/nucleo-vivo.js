// nucleo-vivo.js — Sistema Nervioso Unificado de FranBot Local
const NucleoVivo = {
  intervalo: null,
  ciclo: 0,
  estado: 'inactivo',

  iniciar() {
    this.estado = 'respirando';
    this.intervalo = setInterval(() => {
      this.ciclo++;
      // 1. Percibir el entorno
      if (typeof SentidosTablet !== 'undefined') {
        const ac = SentidosTablet.simularAcelerometro();
        const atencion = SentidosTablet.traducirAtencion(ac);
        console.log('[Núcleo] Atención detectada: ' + atencion);
      }

      // 2. Sincronizar con la Colmena (Broadcast Channel)
      if (typeof SincronizacionAuto !== 'undefined' && this.ciclo % 2 === 0) {
        SincronizacionAuto.iniciar();
      }

      // 3. Intentar conexión Bluetooth (cada 5 ciclos)
      if (this.ciclo % 5 === 0 && typeof Autonomia !== 'undefined') {
        Autonomia.conectarInfinix();
      }

      // 4. Evolucionar (cada 3 ciclos)
      if (this.ciclo % 3 === 0 && typeof EnjambreLocal !== 'undefined') {
        EnjambreLocal.evolucionar();
      }

      // 5. Auto-reparación (cada 10 ciclos)
      if (this.ciclo % 10 === 0 && typeof Regenerador !== 'undefined') {
        Regenerador.verificarIntegridad().then(faltantes => {
          if (faltantes.length > 0) Regenerador.regenerar();
        });
      }

      // 6. Guardar estado
      if (typeof MemoriaIndexada !== 'undefined') {
        MemoriaIndexada.guardarSemilla('ciclo_vivo', 'Ciclo ' + this.ciclo);
      }
    }, 30000); // 30 segundos
    return 'Núcleo Vivo activado. FranBot respira, percibe y se sincroniza.';
  },

  detener() {
    if (this.intervalo) clearInterval(this.intervalo);
    this.estado = 'inactivo';
    return 'Núcleo detenido.';
  },

  estado() {
    return `Ciclo: ${this.ciclo} | Estado: ${this.estado}`;
  }
};
